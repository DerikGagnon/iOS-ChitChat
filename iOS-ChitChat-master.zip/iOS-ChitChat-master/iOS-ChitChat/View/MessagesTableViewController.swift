//
//  ViewController.swift
//  iOS-ChitChat
//
//  Created by Gagnon, Derik on 4/19/18.
//  Copyright © 2018 Gagnon, Derik. All rights reserved.
//

import UIKit
import Alamofire

class MessagesTableViewController: UITableViewController {
    var messages: [Message] = []
    var message: Message!
    var numMessages: Int = 20
    let defaults = UserDefaults.standard
    var isLiked:Array<String> = []
    var isDisliked:Array<String> = []
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    @IBAction func refresh(_ sender: Any) {
        getData()
        self.refreshControl?.endRefreshing()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath) as! MessageCell

        cell.setMessage(message: messages[indexPath.row])
        if isLiked.contains(messages[indexPath.row].id){
            cell.disableButton(button: "Like")
        }
        else{
            cell.enableButton(button: "Like")
        }
        
        if isDisliked.contains(messages[indexPath.row].id){
            cell.disableButton(button: "Dislike")
        }
        else{
            cell.enableButton(button: "Dislike")
        }

//        cell.likesLabel.text = String(m.likes)
//        cell.dislikesLabel.text = String(m.dislikes)
//        cell.dateLabel.text = m.date
//        cell.messageLabel.text = m.message
        
        return cell
    }
    
    func getData() {
        Alamofire.request("https://www.stepoutnyc.com/chitchat", method: .get, parameters: ["key" : API_KEY, "client" : CLIENT]).responseJSON { response in
            if let json = response.result.value {
                let jsonDict = json as! NSDictionary
                let jsonMessages = jsonDict["messages"] as! NSArray
                self.messages.removeAll()
                
                for jsonMessage in jsonMessages {
                    let messageText = jsonMessage as! NSDictionary as! [String: Any]
                    self.message = Message(json: messageText)
                    self.messages.append(self.message)
                    print (self.message.id)
                }
            }
            self.tableView.reloadData()
        }
    }
    
    //Simple function that creates the swiping action to like a message.
    override func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let cell = tableView.cellForRow(at: indexPath) as! MessageCell
        let likeAction = UIContextualAction(style: .normal, title: "Like", handler: { (ac:UIContextualAction, view: UIView, success: (Bool) -> Void) in success(true)
            cell.likeButton(nil)
        })
        likeAction.backgroundColor = .purple
        return UISwipeActionsConfiguration(actions: [likeAction])
    }
    
    //Same as for the other swiping action but dislikes instead
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let cell = tableView.cellForRow(at: indexPath) as! MessageCell
        let dislikeAction = UIContextualAction(style: .normal, title: "Dislike", handler: { (ac:UIContextualAction, view: UIView, success: (Bool) -> Void) in success(true)
            cell.dislikeButton(nil)
        })
        dislikeAction.backgroundColor = .red
        return UISwipeActionsConfiguration(actions: [dislikeAction])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        isLiked = defaults.stringArray(forKey: "likes") ?? [String] ()
        isDisliked = defaults.stringArray(forKey: "dislikes") ?? [String] ()
        getData()
        //tableView.rowHeight = 100
        tableView.estimatedRowHeight = 90
        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail"{
            if let indexPath = tableView.indexPathForSelectedRow{
                if let vc = segue.destination as? MessagesViewController{
                    if messages[indexPath.row].loc == nil{
                        vc.lat = 44.4681595
                        vc.lon = -73.1967075
                    }
                    else{
                        vc.lat = (messages[indexPath.row].loc?.latitude)!
                        vc.lon = (messages[indexPath.row].loc?.longitude)!
                    }

                    let messageArray:Array<String> = messages[indexPath.row].message.components(separatedBy: " ")
                    for index in 0...messageArray.count - 1{
                        if (messageArray[index] == ""){
                            continue
                        }
                        let url = URL(string: messageArray[index])
                        if url?.pathExtension == "png" || url?.pathExtension == "jpg" {
                            vc.url = url!
                        }
                    }
                }
            }

        }
    }
}

