# iOS-ChitChat
An iOS Yik Yak clone called Chit Chat.

This app uses Alamofire as a dependency and for making get and post requests to a server.
